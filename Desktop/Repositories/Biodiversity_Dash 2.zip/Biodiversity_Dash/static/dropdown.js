/* data route */
var url = "/names";



function buildPlot() {
        var response = {{names_data|tojson}};
        console.log(response);
      };

buildPlot();

//
// function build_dropdown(base_url){
//   console.log('build_dropdown working' )
//   var url = base_url + "/names"
//
//   d3.json(url, function(error, response) {
//         if (error) return console.warn(error);
//
//         select_elem = document.getElementById('#selSamples')
//         if(select_elem){
//             for(var i = 0; i < response.length; i++) {
//                 var option = document.createElement('option');
//                 option.innerHTML = response[i];
//                 option.value = response[i];
//                 select_elem.appendChild('option');
//               };
//             };
//           });
//
// };
//
// build_dropdown(base_url);
